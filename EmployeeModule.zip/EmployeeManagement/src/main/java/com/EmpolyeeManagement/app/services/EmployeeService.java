package com.EmpolyeeManagement.app.services;

import com.EmpolyeeManagement.app.entity.Employee;
import com.EmpolyeeManagement.app.entity.Attendance;
import com.EmpolyeeManagement.app.repository.EmployeeRepository;
import com.EmpolyeeManagement.app.repository.AttendanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private AttendanceRepository attendanceRepository;

    // Save a new Employee
    public Employee saveEmployee(Employee employee) {
        try {
            return employeeRepository.save(employee);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Employee with this email or PF Number already exists.");
        }
    }

    // Get all employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Get Employee by ID
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    // Update Employee by ID
    public Employee updateEmployee(Long id, Employee employee) {
        return employeeRepository.findById(id).map(existingEmployee -> {
            existingEmployee.setName(employee.getName());
            existingEmployee.setEmail(employee.getEmail());
            existingEmployee.setPhoneNumber(employee.getPhoneNumber());
            existingEmployee.setGender(employee.getGender());
            existingEmployee.setDateOfBirth(employee.getDateOfBirth());
            existingEmployee.setAddress(employee.getAddress());
            existingEmployee.setJobTitle(employee.getJobTitle());
            existingEmployee.setDepartment(employee.getDepartment());
            existingEmployee.setRole(employee.getRole());
            existingEmployee.setDateOfJoining(employee.getDateOfJoining());
            existingEmployee.setEmployeeType(employee.getEmployeeType());
            existingEmployee.setStatus(employee.getStatus());
            existingEmployee.setReportingManager(employee.getReportingManager());
            existingEmployee.setSalary(employee.getSalary());
            existingEmployee.setTaxDeductions(employee.getTaxDeductions());
            existingEmployee.setPfNumber(employee.getPfNumber());
            existingEmployee.setBankAccountDetails(employee.getBankAccountDetails());
            existingEmployee.setLeaveBalance(employee.getLeaveBalance());
            existingEmployee.setAssignedAssets(employee.getAssignedAssets());
            return employeeRepository.save(existingEmployee);
        }).orElse(null);
    }

    // Delete Employee by ID
    public boolean deleteEmployee(Long id) {
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return true;
        }
        return false;
    }

    // Get Attendance by Employee ID
    public List<Attendance> getAttendanceByEmployeeId(Long employeeId) {
        // Ensure that the employee exists before fetching attendance
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        return attendanceRepository.findByEmployeeId(employeeId);  // Fetch attendance by employee ID
    }

    // Apply Leave Request for Employee
    public Attendance applyAttendance1(Long employeeId, Attendance attendance) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        attendance.setEmployee(employee);  // Set the employee associated with this attendance record
        return attendanceRepository.save(attendance);
    }
    
    
 // Apply Attendance for Employee
    public Attendance applyAttendance(Long employeeId, Attendance attendance) {
        // Check if the employee exists
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        // Set the employee reference in the attendance record
        attendance.setEmployee(employee);  // Associate the attendance with the employee

        // Save the attendance record
        return attendanceRepository.save(attendance);  // Persist the attendance record to the database
    }

    

        // Get Attendance by Employee ID
        public List<Attendance> getAttendanceByEmployeeId1(Long employeeId) {
            // Ensure the employee exists
            Employee employee = employeeRepository.findById(employeeId)
                    .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

            // Fetch and return the attendance records for the employee
            return attendanceRepository.findByEmployeeId(employeeId);  // Custom method in AttendanceRepository
        }

        // Other service methods (save, update, delete, etc.)
    }

    
    
    
    
    
    

