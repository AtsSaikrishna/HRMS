package com.EmpolyeeManagement.app.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class LeaveRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;  // Many-to-One relationship with Employee

    @Column(name = "leave_type", nullable = false)
    private String leaveType;  // e.g., Sick Leave, Casual Leave

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;  // Start date of the leave

    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;  // End date of the leave

    @Column(name = "status", nullable = false)
    private String status;  // e.g., Pending, Approved, Rejected

    public LeaveRequest() {
    }

    public LeaveRequest(Employee employee, String leaveType, LocalDate startDate, LocalDate endDate, String status) {
        this.employee = employee;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    // Getters and Setters
}
