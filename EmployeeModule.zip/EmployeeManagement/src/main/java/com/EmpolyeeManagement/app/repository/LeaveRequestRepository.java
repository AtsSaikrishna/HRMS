package com.EmpolyeeManagement.app.repository;

import com.EmpolyeeManagement.app.entity.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

    // Custom query to find leave requests by employee ID
    List<LeaveRequest> findByEmployeeId(Long employeeId);

    // Optional: Query to find leave requests by status
    List<LeaveRequest> findByStatus(String status);
}
