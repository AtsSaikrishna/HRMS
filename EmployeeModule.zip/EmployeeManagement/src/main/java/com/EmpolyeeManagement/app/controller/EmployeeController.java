package com.EmpolyeeManagement.app.controller;

import com.EmpolyeeManagement.app.entity.Employee;
import com.EmpolyeeManagement.app.entity.Attendance;
import com.EmpolyeeManagement.app.response.ResponseMessage;
import com.EmpolyeeManagement.app.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // Create a new employee
    @PostMapping
    public ResponseEntity<ResponseMessage> addEmployee(@RequestBody Employee employee) {
        try {
            // Try to save the employee; if there's a duplicate email or other issue, it will throw an exception
            Employee createdEmployee = employeeService.saveEmployee(employee);
            return new ResponseEntity<>(
                    new ResponseMessage("Employee created successfully.", HttpStatus.CREATED.value(), createdEmployee),
                    HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            // Handle duplicate entry error, or any other error
            return new ResponseEntity<>(
                    new ResponseMessage(e.getMessage(), HttpStatus.BAD_REQUEST.value(), null),
                    HttpStatus.BAD_REQUEST);
        }
    }

    // Get all employees
    @GetMapping
    public ResponseEntity<ResponseMessage> getAllEmployees() {
        return new ResponseEntity<>(
                new ResponseMessage("Employees retrieved successfully.", HttpStatus.OK.value(), employeeService.getAllEmployees()),
                HttpStatus.OK);
    }

    // Get employee by ID
    @GetMapping("/{id}")
    public ResponseEntity<ResponseMessage> getEmployeeById(@PathVariable Long id) {
        Employee employee = employeeService.getEmployeeById(id);
        if (employee != null) {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee retrieved successfully.", HttpStatus.OK.value(), employee),
                    HttpStatus.OK);
        } else {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee not found.", HttpStatus.NOT_FOUND.value(), null),
                    HttpStatus.NOT_FOUND);
        }
    }

    // Update employee by ID
    @PutMapping("/{id}")
    public ResponseEntity<ResponseMessage> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        Employee updatedEmployee = employeeService.updateEmployee(id, employee);
        if (updatedEmployee != null) {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee updated successfully.", HttpStatus.OK.value(), updatedEmployee),
                    HttpStatus.OK);
        } else {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee not found.", HttpStatus.NOT_FOUND.value(), null),
                    HttpStatus.NOT_FOUND);
        }
    }

    // Delete employee by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<ResponseMessage> deleteEmployee(@PathVariable Long id) {
        boolean isDeleted = employeeService.deleteEmployee(id);
        if (isDeleted) {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee deleted successfully.", HttpStatus.NO_CONTENT.value(), null),
                    HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(
                    new ResponseMessage("Employee not found.", HttpStatus.NOT_FOUND.value(), null),
                    HttpStatus.NOT_FOUND);
        }
    }

    // Get attendance by Employee ID
    @GetMapping("/{id}/attendance")
    public ResponseEntity<ResponseMessage> getAttendanceByEmployeeId(@PathVariable Long id) {
        try {
            List<Attendance> attendanceRecords = employeeService.getAttendanceByEmployeeId(id);
            if (attendanceRecords != null && !attendanceRecords.isEmpty()) {
                return new ResponseEntity<>(
                        new ResponseMessage("Attendance records retrieved successfully.", HttpStatus.OK.value(), attendanceRecords),
                        HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        new ResponseMessage("No attendance records found for this employee.", HttpStatus.NOT_FOUND.value(), null),
                        HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseMessage("Error retrieving attendance: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), null),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    


        // Apply Attendance for Employee
        @PostMapping("/{id}/attendance")
        public ResponseEntity<ResponseMessage> applyAttendance(
                @PathVariable Long id, @RequestBody Attendance attendance) {
            try {
                Attendance appliedAttendance = employeeService.applyAttendance(id, attendance);
                return new ResponseEntity<>(
                        new ResponseMessage("Attendance applied successfully.", HttpStatus.CREATED.value(), appliedAttendance),
                        HttpStatus.CREATED);
            } catch (IllegalArgumentException e) {
                return new ResponseEntity<>(
                        new ResponseMessage(e.getMessage(), HttpStatus.BAD_REQUEST.value(), null),
                        HttpStatus.BAD_REQUEST);
            }
        }

        // Other methods like Get, Update, etc.
    }



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

