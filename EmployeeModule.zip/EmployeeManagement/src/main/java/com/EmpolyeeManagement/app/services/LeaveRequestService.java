package com.EmpolyeeManagement.app.services;

import com.EmpolyeeManagement.app.entity.Employee;
import com.EmpolyeeManagement.app.entity.LeaveRequest;
import com.EmpolyeeManagement.app.repository.EmployeeRepository;
import com.EmpolyeeManagement.app.repository.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    // Apply for leave
    public LeaveRequest applyLeave(Long employeeId, LeaveRequest leaveRequest) {
        // Check if employee exists
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        // Set the employee on the leave request
        leaveRequest.setEmployee(employee);

        // Set the status to "Pending" by default
        leaveRequest.setStatus("Pending");

        // Save the leave request
        return leaveRequestRepository.save(leaveRequest);
    }

    // Get leave requests by employee ID
    public List<LeaveRequest> getLeaveRequestsByEmployeeId(Long employeeId) {
        return leaveRequestRepository.findByEmployeeId(employeeId);
    }

    // Get all leave requests by status (e.g., Pending, Approved)
    public List<LeaveRequest> getLeaveRequestsByStatus(String status) {
        return leaveRequestRepository.findByStatus(status);
    }
}
