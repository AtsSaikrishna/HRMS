package com.EmpolyeeManagement.app.controller;

import com.EmpolyeeManagement.app.entity.LeaveRequest;
import com.EmpolyeeManagement.app.response.ResponseMessage;
import com.EmpolyeeManagement.app.services.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/employees")
public class LeaveRequestController {

    @Autowired
    private LeaveRequestService leaveRequestService;

    // Apply for Leave
    @PostMapping("/{id}/leaveRequest")
    public ResponseEntity<ResponseMessage> applyLeave(
            @PathVariable Long id, @RequestBody LeaveRequest leaveRequest) {
        try {
            LeaveRequest appliedLeave = leaveRequestService.applyLeave(id, leaveRequest);
            return new ResponseEntity<>(
                    new ResponseMessage("Leave request submitted successfully.", HttpStatus.CREATED.value(), appliedLeave),
                    HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(
                    new ResponseMessage(e.getMessage(), HttpStatus.BAD_REQUEST.value(), null),
                    HttpStatus.BAD_REQUEST);
        }
    }

    // Get Leave Requests by Employee ID
    @GetMapping("/{id}/leaveRequest")
    public ResponseEntity<ResponseMessage> getLeaveRequestsByEmployeeId(@PathVariable Long id) {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsByEmployeeId(id);
        if (leaveRequests != null && !leaveRequests.isEmpty()) {
            return new ResponseEntity<>(
                    new ResponseMessage("Leave requests retrieved successfully.", HttpStatus.OK.value(), leaveRequests),
                    HttpStatus.OK);
        } else {
            return new ResponseEntity<>(
                    new ResponseMessage("No leave requests found for this employee.", HttpStatus.NOT_FOUND.value(), null),
                    HttpStatus.NOT_FOUND);
        }
    }
}
