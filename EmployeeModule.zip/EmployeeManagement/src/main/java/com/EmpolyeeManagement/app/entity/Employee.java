package com.EmpolyeeManagement.app.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    
 

        @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
        private List<Attendance> attendanceRecords1; // One-to-Many relationship with Attendance

        // Getters and Setters
 

    private String name;

    @Column(unique = true, nullable = false)
    private String email;  // Unique constraint for email

    @Column(name = "phone_number", nullable = false)
    private String phoneNumber;

    private String gender;

    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;

    private String address;

    @Column(name = "job_title", nullable = false)
    private String jobTitle;

    private String department;

    private String role;

    @Column(name = "date_of_joining", nullable = false)
    private LocalDate dateOfJoining;

    @Column(name = "employee_type", nullable = false)
    private String employeeType; // Full-Time, Part-Time, Contract

    private String status; // Active, Inactive

    @Column(name = "reporting_manager")
    private String reportingManager;

    private Double salary;

    @Column(name = "tax_deductions")
    private Double taxDeductions;

    @Column(name = "pf_number", unique = true)
    private String pfNumber;  // Unique constraint for pfNumber

    @Column(name = "bank_account_details")
    private String bankAccountDetails;

    @Column(name = "leave_balance", nullable = false)
    private Integer leaveBalance;

    @Column(name = "assigned_assets")
    private String assignedAssets; // Example: Laptop, Mobile, etc.

    @JsonIgnore
    private String password;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Attendance> attendanceRecords;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<LeaveRequest> leaveRequests;

    // Default Constructor
    public Employee() {}

    // Constructor with all fields
    public Employee(String name, String email, String phoneNumber, String gender, LocalDate dateOfBirth, String address,
                    String jobTitle, String department, String role, LocalDate dateOfJoining, String employeeType,
                    String status, String reportingManager, Double salary, Double taxDeductions, String pfNumber,
                    String bankAccountDetails, Integer leaveBalance, String assignedAssets, String password) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.jobTitle = jobTitle;
        this.department = department;
        this.role = role;
        this.dateOfJoining = dateOfJoining;
        this.employeeType = employeeType;
        this.status = status;
        this.reportingManager = reportingManager;
        this.salary = salary;
        this.taxDeductions = taxDeductions;
        this.pfNumber = pfNumber;
        this.bankAccountDetails = bankAccountDetails;
        this.leaveBalance = leaveBalance;
        this.assignedAssets = assignedAssets;
        this.password = password;
    }

    // Getters and Setters for all fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(String employeeType) {
        this.employeeType = employeeType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReportingManager() {
        return reportingManager;
    }

    public void setReportingManager(String reportingManager) {
        this.reportingManager = reportingManager;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Double getTaxDeductions() {
        return taxDeductions;
    }

    public void setTaxDeductions(Double taxDeductions) {
        this.taxDeductions = taxDeductions;
    }

    public String getPfNumber() {
        return pfNumber;
    }

    public void setPfNumber(String pfNumber) {
        this.pfNumber = pfNumber;
    }

    public String getBankAccountDetails() {
        return bankAccountDetails;
    }

    public void setBankAccountDetails(String bankAccountDetails) {
        this.bankAccountDetails = bankAccountDetails;
    }

    public Integer getLeaveBalance() {
        return leaveBalance;
    }

    public void setLeaveBalance(Integer leaveBalance) {
        this.leaveBalance = leaveBalance;
    }

    public String getAssignedAssets() {
        return assignedAssets;
    }

    public void setAssignedAssets(String assignedAssets) {
        this.assignedAssets = assignedAssets;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Attendance> getAttendanceRecords() {
        return attendanceRecords1;
    }

    public void setAttendanceRecords(List<Attendance> attendanceRecords) {
        this.attendanceRecords1 = attendanceRecords;
    }

    public List<LeaveRequest> getLeaveRequests() {
        return leaveRequests;
    }

    public void setLeaveRequests(List<LeaveRequest> leaveRequests) {
        this.leaveRequests = leaveRequests;
    }
}
